<?php
function searchBin($filename, $binToSearch) {
    // Leer el archivo de texto
    $file = fopen($filename, "r");
    while (($line = fgetcsv($file, 0, "|")) !== FALSE) {
        // Asegúrate de que cada línea tenga la cantidad correcta de campos
        if (count($line) == 13) {
            // Usa el BIN como clave
            $bin = trim($line[0]);
            if ($bin == $binToSearch) {
                return array(
                    "code" => trim($line[1]),
                    "brand" => trim($line[2]),
                    "type" => trim($line[3]),
                    "level" => trim($line[4]),
                    "bank_name" => trim($line[5]),
                    "bank_site" => trim($line[6]),
                    "bank_phone" => trim($line[7]),
                    "country_name" => trim($line[8]),
                    "ISO2" => trim($line[9]),
                    "ISO3" => trim($line[10]),
                    "currency" => trim($line[11]),
                    "flag" => trim($line[12]),
                    "Owner" => ("X/z")
                );
            }
        }
    }
    fclose($file);

    return NULL;
}

// Obtener el BIN de la URL
$bin = $_GET['binsearch'];

// Buscar el BIN específico
$result = searchBin("bins.txt", $bin);

// Imprimir el resultado
if ($result !== NULL) {
    echo json_encode($result);
} else {
    echo "BIN no encontrado";
}
?>
