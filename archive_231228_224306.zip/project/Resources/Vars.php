<?php

/* Setting the timezone. */
date_default_timezone_set("Asia/Kolkata");

/* Defining the bot token. */
define('bot_token','6230387259:AAE5yrZZ6Tg5lmVb-QWyuxAHRXDnYUZMxdY');
define('msgtext', $text);

$bot_username = "Mikaza";

/* It's setting the date and time. */
$fecha = date('d-m-Y h:i:s A');

/* It's just a variable that contains the name of the owner of the bot. */
$propietario = "Andy";

/* Getting the data from the POST request sent by Telegram. */
// $update =  json_decode(file_get_contents('php://input'), true);
$update = file_get_contents('php://input');
$update = json_decode($update,true);

$tlg = "<a href='tg://user?id=$user_id'>$ufname</a>";
$tlg2 = "<a href='tg://user?id=$callbackuserid'>".htmlspecialchars($callbackfname.$callbacklname)."</a>";

//basic
$text       = $update["message"]["text"];
// $text       = $update->message->text;
$photo      = $update["message"]["photo"];
$date       = $update["message"]["date"];
$chat_id    = $update["message"]["chat"]["id"];
$msg_id     = $update["message"]["message_id"];
$lang = strtoupper($update['message']['from']['language_code']);


//Chat
$cfname     = $update['message']['chat']['first_name'];
$cid        = $update["message"]["chat"]["id"];
$clast_name = $update['message']['chat']['last_name'];
$ctype      = $update["message"]["chat"]["type"];
$ctitle     = $update['message']['chat']['title'];
$chatname = $update["message"]["chat"]["title"]; 
$new_chat_member = $update["message"]["new_chat_member"];
$newfirstname = $update["message"]["new_chat_member"]["first_name"];
$newusername = $update["message"]["new_chat_member"]["username"];
$newgId = $update["message"]["new_chat_member"]["id"];

//user info
$ufname     = $update['message']['from']['first_name'];
$uname      = $update['message']['from']['last_name'];
$username   = $update['message']['from']['username'];
$username1 = ("@").$username;
$user_id    = $update['message']['from']['id'];

//reply info
$quetzal     = $update['message']['reply_to_message']['text'];
$reply_mId = $update['message']['reply_to_message']['message_id']; 
$r_uId = $update['message']['reply_to_message']['from']['id'];
$r_user = $update['message']['reply_to_message']['from']['username'];
$r_fname = $update['message']['reply_to_message']['from']['first_name'];

//callback

$data              = $update['callback_query']['data'];
$callbackid        = $update['callback_query']['id'];
$callbackfrom      = $update['callback_query']['from']['id'];
$callbackfname     = $update['callback_query']['from']['first_name'];
$callbacklname     = $update['callback_query']['from']['last_name'];
$callbackusername  = $update['callback_query']['from']['username'];
$callbackchatid    = $update['callback_query']['message']['chat']['id'];
$callbackuserid    = $update['callback_query']['message']['reply_to_message']['from']['id'];
$callbackmessageid = $update['callback_query']['message']['message_id'];
$callbackbin = $update['callback_query']['message']['reply_to_message']['text'];



