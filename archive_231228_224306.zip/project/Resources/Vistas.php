<?php
require_once '/home/hestiaccbot/www/project/Resources/inline.php';
/*comando Principal para Definir Gateways*/
$auth = "<b><i>$_ Auth Gateway ⛈</i></b>\n<b>Important:</b> <i>At the moment there are no commands added for this keyboard section, this will only be visible now that I'm in beta, over time there will be many commands in this area!</i>";
$charge = "Gateway え <b><i>Sakura Sh+B3</i></b>
Status え <b>[ ON ✅ ]</b>
Ultima Vista: <code>2023-12-24 17:14:44</code>
Nota え <i>Ninguna</i>
<b>- - - - - - - - - - - - - - - - - - - - -</b>
Gateway え <b><i>Nana Sh+B3 2</i></b>
Status え <b>[ ON ✅ ]</b>
Ultima Vista: <code>2023-12-24 17:14:44</code>
Nota え <i>Ninguna</i>
<b>- - - - - - - - - - - - - - - - - - - - -</b>
Gateway え <b><i>Nandayo Shopify 2</i></b>
Status え <b>[ ON ✅ ]</b>
Ultima Vista: <code>2023-12-24 17:14:44</code>
Nota え <i>Ninguna</i>
<b>- - - - - - - - - - - - - - - - - - - - -</b>
Gateway え <b><i>Moneko Shopify 1</i></b>
Status え <b>[ ON ✅ ]</b>
Ultima Vista: <code>2023-12-24 17:14:44</code>
Nota え <i>Ninguna</i>";
$masive = "<b><i>Mass Gateway ⛈</i>
Important:</b> <i>At the moment there are no commands added for this keyboard section, this will only be visible now that I'm in beta, over time there will be many commands in this area!</i>";
$alert = "Oops, Denied Access ⚠️";


$gates = "<b><i>🎄️ <a href='tg://user?id=6230387259'>Hestia</a> | <a href='https://t.me/Team_HestiaChk'>𝑿/𝒛</a>
- - - - - - - - - - - - - - - - - - - - -
Total Premium Gateways: 10
   - ON: <code>4</code> ✅
   - OFF: <code>6</code> ❌
- - - - - - - - - - - - - - - - - - - - -
Total normal Gateways: 10
   - ON: <code>0</code> ✅
   - OFF: <code>10</code> ❌</i></b>";

/*comando Para Cmds Principal No gates*/
$principalcmds = "<i><b>Hello $username1!
I am <a href='tg://user?id=6230387259'>Hestia</a> Welcome to the command section, you can interact with the buttons
Copyright ©️ 2023 | <a href='https://t.me/Team_HestiaChk'>𝑿/𝒛</a></b></i>";

$cboton = "Gateways";
$cboton1 = "Tools";
$cboton2 = "Bio";
$cboton3 = "Cerrar Menú";
$cboton4 = "Desarrolladores";
$homecmds = "<b>Reintentar, Bienvenido a la sección de comandos. Puede interactuar con los botones para navegar a través de los comandos. ⤵️</b>";

/*exit seccion cmds*/
$cerrare = "<b>Menú cerrado <a href='t.me/$callbackusername'>$callbackfname</a></b>";

/*Boton Y Bio Información*/
$infboton = "Atras";
$bio = "<b>[☩] Información del Usuario: @$usernamecallback
━ ━ ━ ━ ━ ━ ━ ━
↳ ID: $callbackuserid
↳ Estado: $title
↳ Registrado: $date
━ ━ ━ ━
↳ Plan: $plan
↳ Créditos: $credits
↳ Anti-spam: $antispam
━ ━ ━ ━ ━ ━</b>";

/* It's a variable that contains a string. */
$start = "<i><b>Hello $username1!
I am <a href='tg://user?id=6230387259'>Hestia</a> from <a href='https://t.me/Team_HestiaChk'>𝑿/𝒛</a>
hit /cmds to chek my all Available commands.</b></i>";
$sboton = "Hecho por";
$sboton1 = "Agregame";
$sboton2 = "Support";
$sboton3 = "Selling";
$stimagen = "https://i.pinimg.com/564x/3c/25/c9/3c25c971df6d412f61023e1467392a01.jpg";
$tools = "<b>Hestia — <a href='https://t.me/Team_HestiaChk'>𝑿/𝒛</a>  [🧸] — Pag: <code>2</code>
- - - - - - - - - - - - - - - - - - - - -
↳ Busqueda Anime: /anime
× Status: OFF ⚠️
× Ultima Vista: <code>2023-03-24 06:08:36 PM</code>
× Nota: <i>No Added :(</i>
- - - - - - - - - - - - - - - - - - - - -
↳ Masiva Búsqueda Bin: /xbin
× Status: ON ✅
× Ultima Vista: <code>2023-10-05 07:34:32</code>
× Nota: <i>Sin Notas!</i>
- - - - - - - - - - - - - - - - - - - - -
↳ Búsqueda de Ip: /ip
× Status: ON ✅
× Ultima vista: <code>2023-05-13 06:08:38 PM </code>
× Nota: <i>Sin Notas</i>
- - - - - - - - - - - - - - - - - - - - -
↳ Generador De Dirección: /rnd
× Status: ON ✅
× Ultima Vista: <code>2023-05-13 06:08:40 PM</code>
× Nota: <i>Sin Notas</i>
- - - - - - - - - - - - - - - - - - - - -</b>";
$herramientas = "<b>Hestia — <a href='https://t.me/Team_HestiaChk'>𝑿/𝒛</a>  [❄️] — Pag: <code>1</code>
- - - - - - - - - - - - - - - - - - - - -
⇾ Bin Info: /bin
× Status: ON ✅
× Ultima Vista: <code>2023-03-24 06:08:36 PM</code>
× Nota: <i>Sin Notas.</i>
- - - - - - - - - - - - - - - - - - - - -
⇾ Buy violett Premium Access: /buy
× Status: ON ✅
× Ultima Vista: <code>2023-10-05 07:34:32</code>
× Nota: <i>Sin Notas!</i>
- - - - - - - - - - - - - - - - - - - - -
⇾ Tarjetas Extras: /extra
× Status: ON ✅
× Ultima vista: <code>2023-05-13 06:08:38 PM </code>
× Nota: <i>Sin Notas</i>
- - - - - - - - - - - - - - - - - - - - -
⇾ Card Generator: /gen
× Status: ON ✅
× Ultima Vista: <code>2023-05-13 06:08:40 PM</code>
× Nota: <i>Sin Notas</i>
- - - - - - - - - - - - - - - - - - - - -
⇾ Claim a Key: /claim
× Status: ON ✅
× Ultima Vista: <code>2023-04-22 17:14:44</code>
× Nota: <i>Ninguna</i>
- - - - - - - - - - - - - - - - - - - - -
⇾ Cryptocurrency Price: /crypto
× Status: OFF ⚠️
× Ultima Vista: <code>2023-03-18 05:21:41 </code>
× Nota: <i>La api Esta Muerta!</i>
- - - - - - - - - - - - - - - - - - - - -</b>";

