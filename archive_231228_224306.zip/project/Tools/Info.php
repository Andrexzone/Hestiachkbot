<?php
require_once '/home/hestiaccbot/www/project/Resources/Functions.php';

if (is_valid_command($text, array("info"))) {    
    if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
autoRegisterUser($user_id, $username, $chat_id, $msg_id);

if (!get_authorize($chat_id, $msg_id)) {
        return;
}
if (!check_authorization_and_plan($user_id, $msg_id)) {
        return;
}
// Hacer algo si se encuentran los caracteres especiales y la palabra "info"
if(isset($r_uId, $r_user, $r_fname)){
$u_idt = $r_uId;
$r_u = $r_user;
$f_fname = $r_fname;
}else{
$u_idt = $user_id;
$f_fname = $ufname;
$r_u = $username;
}
$sql = "select * from administrar where id='$u_idt'";
$cs = mysqli_query(mysqlcon(),$sql);
$raw = mysqli_fetch_assoc($cs);
$planexpiry = $raw['planexpiry'];
$credits = $raw['creditos'];
$plan = $raw['plan'];
$title = $raw['rango'];
$antispam = $raw['antispam2'];
$date = $raw['sk'];
$warns = $raw['warns'];
mysqli_close(mysqlcon());
$keyboard1 = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "owner", "url" => "https://t.me/jannyex"]
            ]
        ]
    ]);
    
if (isset($update['message']['reply_to_message']['from']['username']) && $update['message']['reply_to_message']['from']['username'] === $bot_username) {
    // Este mensaje es una respuesta al bot, no haremos nada en este caso
    exit();
}
if (empty($username)) {
    $content = ['chat_id' => $chat_id, 'text' => "<i>Por favor, establece un nombre de usuario para continuar.</i>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
    SendMessage($content);
    exit();
}
if (!$raw) {
    $content = ['chat_id' => $chat_id, 'text' => "<b>Hello <a href='tg://user?id=$u_idt'>$r_u</a>, you are not register, please send <code>/register</code> message in chat</b>", 'reply_to_message_id' => $msg_id, 'reply_markup' => $keyboard1, 'parse_mode' => 'html'];
    $m1 = sendmessage($content);
    exit();
}

/*if ($warns >= 3) {
// si el usuario tiene 3 o más warns, enviar un mensaje y salir del script
$msg = "<b>yoruka system project! 🎄
━ • ━━━━━━━━━━━━ • ━
note - ↯ <code>an error occurred 📛</code>
info - ↯ <code>user bloked!!</code></b>";

$content = ['chat_id' => $chat_id, 'text' => $msg, 'reply_to_message_id' => $msg_id, 'reply_markup' => $keyboard1, 'parse_mode' => 'html'];
$m1 = sendmessage($content);
exit();
}
*/


if ($planexpiry == "0") {
    $mensaje = "no tienes un plan activo.";
} else {
    $expiry = date('y-m-d h:i:s', $planexpiry);
    $fechaactual = date('y-m-d h:i:s'); 
    $date1 = new datetime($fechaactual);
    $date2 = new datetime($expiry);
    $diff = $date1->diff($date2);
    $dias = $diff->days;
    $horas = $diff->h;
    $minutos = $diff->i;
    $segundos = $diff->s;
    $mensaje = "" . $dias . " días, " . $horas . " horas, " . $minutos . " minutos y " . $segundos . " segundos";
    }
    if(empty ($r_u)){
        $uusername = "please set a username";
    }else{

        $uusername = "@$r_u";
        
$fboton = "Support";
$pe = "nKkkdkkdkzkkdk!$($(($(#(#((#(#((#(#(_((_(";
$keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "$fboton", "url" => "https://t.me/refes_hestia"]
            ]
        ]
    ]);
$inf = "[☩] Información del Usuario: <i>@$r_u</i>

<b>Nombre -»</b> $f_fname
<b>ID -»</b> <code>$u_idt</code>
<b>Estado -»</b> $plan | $title
<b>Registrado -»</b> <code>$date</code>

<b>Plan Expiry -»</b> <code>$planexpiry</code>
<b>Créditos -»</b> <code>$credits</code>
<b>Anti-spam -»</b> $antispam
<b>Advertencias -»</b> $warns
<b>Lang-code -»</b> $lang
";

$fimage = "https://i.pinimg.com/564x/bc/16/0b/bc160b6e92dd58bdaee02a9e9d86bf96.jpg";
    $content = ['chat_id' => $chat_id, 'photo' => $fimage, 'caption' => $inf, 'reply_to_message_id' => $msg_id, 'reply_markup' => $keyboard, 'parse_mode' => 'html'];
    $m1  = sendphoto($content);
}}



?>