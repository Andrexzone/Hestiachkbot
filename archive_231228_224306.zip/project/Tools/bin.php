<?php
if (is_valid_command($text, array("bin"))) {    
    if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
autoRegisterUser($user_id, $username, $chat_id, $msg_id);
if (!get_authorize($chat_id, $msg_id)) {
        return;
}
    //$bin = explode(" ", $text)[1];
$bin = preg_replace('/[^0-9]+/', '', $text);
$bin = substr($bin, 0, 6);


$binr = preg_replace('/[^0-9]+/', '', $quetzal);
$binf = substr($binr, 0, 6);
$bin = substr($bin, 0, 6);
$bininv = substr($bin, 0, 5);
    if(empty($bin) && empty($binr)){
$content = ['chat_id' => $chat_id, 'text' => "<i>Tools -» Bin Lookup! ♻️</i>
status -» <b>[ON ✅]</b>
Date -» <code>23-06-2023</code>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        $m1  = SendMessage($content);
        exit();

    }if(empty($bin)){
$bin = $binf;
}
if(is_numeric($bin)){
$starttime = microtime(true);
$mytime = 'time1';
$timest = time();

$sql = "select * from administrar where id='$user_id'";
$cs = mysqli_query(mysqlcon(),$sql);
$raw = mysqli_fetch_assoc($cs);
$title = $raw['rango'];
//==================[BIN LOOK-UP]======================//https://bins.antipublic.cc/bins/'.$bin
$fim = json_decode(file_get_contents('https://bins.antipublic.cc/bins/'.$bin), true);
$level = $fim["level"];
$type = $fim["type"];
$brand = $fim["brand"];
$country = $fim["country_name"];
$currency = $fim["currency"][0];
$bank = $fim['bank'];
$flag = $fim["country_flag"];
/*if($level == ""){}else{
$msg = "<b>Forbiden: </b>⚠️";
    $content = ['chat_id' => $chat_id, 'text' => "$msg", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
    die(SendMessage($content));
}
*/
//==================[BIN LOOK-UP-END]======================//

if(empty($country)) {
        $content3 = ['chat_id' => $chat_id, 'text' => "<b>Not Funds! 🔎</b>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
   sendMessage($content3);
        exit();
}

        $content = ['chat_id' => $chat_id, 'text' => "<i>Wait Proccesing Request! ⏳</i>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        $m1  = SendMessage($content);
        $m1i = $m1['result']['message_id'];
        
        sendChatAction(['chat_id' => $chat_id, 'action' => "typing"]);
$informationbin = "<b>🎁 Bin Infomation:-</b>
<i>Bin-» <code>$bin</code>
Name-» <b>$bank</b>
Country-» <b>$country [$flag]</b>
Level-» <b>$level</b>
Type-» <b>$type</b>
Vendor-» <b>$brand</b>
Checked By-» <b>$username1 ⌞ $title ⌝</b>
Took-» 1s
Made By-» <a href='t.me/TeamAlpha_ofc'>𝑿/𝒛</a></i>";
            $content = ['chat_id' => $chat_id, 'text' => $informationbin, 'message_id' => $m1i, 'parse_mode' => 'HTML'];
            $m2  = EditMessageText($content);
}else{
$content = ['chat_id' => $chat_id, 'text' => "<i>Enter a Valid Bin Input! ⚠️</i>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        $m1  = SendMessage($content);
        exit();
}
}