<?php
require_once './Resources/CurlX.php';
if (is_valid_command($text, array("gen"))) {
if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
autoRegisterUser($user_id, $username, $chat_id, $msg_id);
if (!get_authorize($chat_id, $msg_id)) {
        return;
}
$input = substr($text, 5);
if(empty($input)){
$input = $quetzal;
}
// Buscar y capturar el número de la tarjeta de crédito
if (preg_match('/\b[\dxX]{6,19}\b/', $input, $matches)) {
    $cc = $matches[0];
    // Reemplazar "x" con espacios y mantener los espacios originales
    $cc = preg_replace('/[xX]/', 'x', $cc);
    // Rellenar con "x" hasta que tenga una longitud de 16 dígitos
    $cc = str_pad($cc, 16, "x", STR_PAD_RIGHT);
} else {
    // Manejar el caso en que no se encuentra un número de tarjeta válido
}

// Buscar y capturar el mes de vencimiento
if (preg_match('/\b(0[1-9]|1[0-2])\b/', $input, $matches)) {
    $mon = $matches[0];
} else {
    // Manejar el caso en que no se encuentra un mes válido
}

// Buscar y capturar el año de vencimiento
if (preg_match('/\b(20[2-9][0-9]|[2-9][0-9])\b/', $input, $matches)) {
    $year = $matches[0];
    // Convertir el año a formato de 4 dígitos si es necesario
    if (strlen($year) == 2) {
        $year = "20" . $year;
    }
} else {
    // Manejar el caso en que no se encuentra un año válido
}



// Buscar y capturar el código CVV
if (preg_match('/\b\d{3}\b/', $input, $matches)) {
    $cvv = $matches[0];
} else {
    // Manejar el caso en que no se encuentra un código CVV válido
}

$bin = substr($cc, 0, 6);

$keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "Owner!", "url" => "http://t.me/Jannyex"]
            ]
        ]
    ]);

if ((!empty($mon)) && (!is_numeric($mon) || strlen($mon) < 2 || $mon < 1 || $mon > 12)) {
    $msg = "<b>⚠️ <i>Invalid Month -» $replit</i></b>";
    $content = ['chat_id' => $chat_id, 'text' => "$msg", 'reply_markup' => $keyboard, 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
    die(SendMessage($content));
}

if ((!empty($year)) && (!is_numeric($year) || ($year < 23 || ($year > 31 && $year < 2023) || $year > 2031))) {
    $msg = "<b>⚠️ <i>Invalid Year</i></b>";
    $content = ['chat_id' => $chat_id, 'text' => "$msg", 'reply_markup' => $keyboard, 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
    die(SendMessage($content));
}


if (isset($cvv)) {
    if (!ctype_digit($cvv)) {
        // Excepción: la cadena contiene caracteres no numéricos
        // no se muestra un mensaje de error, se permite su uso como CVV
    } elseif (strlen($cvv) != 3) {
        // Error: la cadena es numérica pero no tiene una longitud de 3 caracteres
        $msg = "<b>⚠️ <i>Invalid CVV</i></b>";
        $content = ['chat_id' => $chat_id, 'text' => "$msg", 'reply_markup' => $keyboard, 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
        die(SendMessage($content));
    }
}
if(empty($mon)){
$mon = "rnd";
}if(empty($year)){
$year = "rnd";
}if(empty($cvv)){
$cvv = "rnd";
}
if(strlen($year) == "2"){
$year = "20$year";
}
$ccl = strlen($cc);
$cco = 16;
$ttx = $cco - $ccl;

    $sql = "SELECT * FROM administrar WHERE id='$user_id'";
    $cs = mysqli_query(mysqlcon(),$sql);
    $raw = mysqli_fetch_assoc($cs);
    $plan = $raw['plan'];
    $title = $raw['rango'];
     mysqli_close(mysqlcon());

$Input = "$cc|$mon|$year|$cvv|$ttx";


$f = substr($Input, 0,1);
$c = array(1,2,7,8,9,0);

if(empty($Input) or !is_numeric(substr($Input, 0, 6)) ){
$nput = "<b>Generador de Tarjetas Vía Lunh.⚙
Usa: <code>/gen xxxxxxxxxxxxxxx|xx|xxxx|xxx</code>
<i>Suerte Con tus Bins.</i></b>";
$content = ['chat_id' => $chat_id, 'text' => "$nput", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
die(SendMessage($content));
}

  
$fim = json_decode(file_get_contents('https://hestiaccbot.alwaysdata.net/Apibin.php?binsearch=' . $bin), true);
$level = $fim["level"];
$type = $fim["type"];
$brand = $fim["brand"];
$country = $fim["country_name"];
$emoji = $fim["flag"];
$currency = $fim["currency"];
$bank = $fim['bank_name'];
$bankphone = $fim["bank_phone"];
/*if($level == ""){}else{
$msg = "<b>Forbiden: </b>⚠️";
    $content = ['chat_id' => $chat_id, 'text' => "$msg", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
    die(SendMessage($content));
}
*/
if(empty($brand)) {
        $content3 = ['chat_id' => $chat_id, 'text' => "<i>Bin not found [⚠️]</i>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        sendMessage($content3);
        exit();
}
    $strnew = strtolower($Input);
    $strnew = str_replace($bad,"<b>[censored]</b>",$strnew);
    if (strtolower($strnew) != strtolower($Input)) {
$msg = "Invalido";



$content = ['chat_id' => $chat_id, 'text' => $msg, 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
SendMessage($content);
      exit;
    }
    

$response = file_get_contents("https://hestiaccbot.alwaysdata.net/gen.php?lista=$Input");
$starttime = microtime(true);
$mytime = 'time1';
$ccg = "<code>$brand - $type - $bank - $country $emoji - $$currency</code>
<b><i>Execute Time {$mytime($starttime)}(s)</i></b>
$response";

$keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "Regenerate 🔄", "callback_data" => "gen"]
                ],
                [
                ["text" => "Delete 🗑️", "callback_data" => "del"]
            ]
        ]
    ]);
$content = ['chat_id' => $chat_id, 'text' => $ccg, 'reply_to_message_id' => $msg_id, 'reply_markup'=>$keyboard,'parse_mode' => "HTML"];
SendMessage($content);
}

if($data == "del"){
     if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => "Access denied opens another session to use it ❌", "show_alert" => true];
        answerCallbackQuery($content);
    } else {
$del = "<b><i>Seccion Ended By: <a href='tg://user?id=$callbackuserid'>$callbackusername</a></i></b>";
$content = ['chat_id' => $callbackchatid, 'message_id'=>$callbackmessageid , 'text' => $del, 'reply_to_message_id' => $callbackmessageid , 'reply_markup'=>$keyboard,'parse_mode' => "HTML"];
  EditMessageText($content);
    
    }
}
    

////////////////////////////////////////////////////// CALLBACK DATAS
if($data == "gen"){
     if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => "Access denied opens another session to use it ❌", "show_alert" => true];
        answerCallbackQuery($content);
    } else {
    $input = substr($callbackbin, 5);
       
// Buscar y capturar el número de la tarjeta de crédito
if (preg_match('/\b[\dxX]{6,19}\b/', $input, $matches)) {
    $cc = $matches[0];
    // Reemplazar "x" con espacios y mantener los espacios originales
    $cc = preg_replace('/[xX]/', 'x', $cc);
    // Rellenar con "x" hasta que tenga una longitud de 16 dígitos
    $cc = str_pad($cc, 16, "x", STR_PAD_RIGHT);
} else {
    // Manejar el caso en que no se encuentra un número de tarjeta válido
}


// Buscar y capturar el mes de vencimiento
if (preg_match('/\b(0[1-9]|1[0-2])\b/', $input, $matches)) {
    $mon = $matches[0];
} else {
    // Manejar el caso en que no se encuentra un mes válido
}
// Buscar y capturar el año de vencimiento
if (preg_match('/\b(20[2-9][0-9]|[2-9][0-9])\b/', $input, $matches)) {
    $year = $matches[0];
    // Convertir el año a formato de 4 dígitos si es necesario
    if (strlen($year) == 2) {
        $year = "20" . $year;
    }
} else {
    // Manejar el caso en que no se encuentra un año válido
}



// Buscar y capturar el código CVV
if (preg_match('/\b\d{3}\b/', $input, $matches)) {
    $cvv = $matches[0];
} else {
    // Manejar el caso en que no se encuentra un código CVV válido
}



$keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "Owner!", "url" => "http://t.me/Jannyex"]
            ]
        ]
    ]);

if ((!empty($mon)) && (!is_numeric($mon) || strlen($mon) < 2 || $mon < 1 || $mon > 12)) {
    $msg = "<b>⚠️ <i>Invalid Month -» $replit</i></b>";
    $content = ['chat_id' => $chat_id, 'text' => "$msg", 'reply_markup' => $keyboard, 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
    die(SendMessage($content));
}

if ((!empty($year)) && (!is_numeric($year) || ($year < 23 || ($year > 31 && $year < 2023) || $year > 2031))) {
    $msg = "<b>⚠️ <i>Invalid Year</i></b>";
    $content = ['chat_id' => $chat_id, 'text' => "$msg", 'reply_markup' => $keyboard, 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
    die(SendMessage($content));
}


if (isset($cvv)) {
    if (!ctype_digit($cvv)) {
        // Excepción: la cadena contiene caracteres no numéricos
        // no se muestra un mensaje de error, se permite su uso como CVV
    } elseif (strlen($cvv) != 3) {
        // Error: la cadena es numérica pero no tiene una longitud de 3 caracteres
        $msg = "<b>⚠️ <i>Invalid CVV</i></b>";
        $content = ['chat_id' => $chat_id, 'text' => "$msg", 'reply_markup' => $keyboard, 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
        die(SendMessage($content));
    }
}
$bin = substr($cc, 0, 6);

if(empty($mon)){
$mon = "rnd";
}if(empty($year)){
$year = "rnd";
}if(empty($cvv)){
$cvv = "rnd";
}
if(strlen($year) == "2"){
$year = "20$year";
}
$ccl = strlen($cc);
$cco = 16;
$ttx = $cco - $ccl;


    $sql = "SELECT * FROM administrar WHERE id='$callbackuserid'";
    $cs = mysqli_query(mysqlcon(),$sql);
    $raw = mysqli_fetch_assoc($cs);
    $plan = $raw['plan'];
    $title = $raw['rango'];
     mysqli_close(mysqlcon());

$Input = "$cc|$mon|$year|$cvv|$ttx";


$f = substr($Input, 0,1);
$c = array(1,2,7,8,9,0);

if(empty($Input) or !is_numeric(substr($Input, 0, 6)) ){
$content = ['chat_id' => $chat_id, 'text' => "<code>Credit Card Generator💳</code>\n<code>Format Example</code>\n<code>/gen 451014|05|23|xxx</code>", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
die(SendMessage($content));
}
$fim = json_decode(file_get_contents('https://hestiaccbot.alwaysdata.net/Apibin.php?binsearch=' . $bin), true);
$level = $fim["level"];
$type = $fim["type"];
$brand = $fim["brand"];
$country = $fim["country_name"];
$emoji = $fim["flag"];
$currency = $fim["currency"];
$bank = $fim['bank_name'];
$bankphone = $fim["bank_phone"];
if(empty($brand)) {
        $content3 = ['chat_id' => $chat_id, 'text' => "<b>Bin not found [⚠️]</b>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        sendMessage($content3);
        exit();
}

    $bad = '123456,123,88888,66666,77777,99999,111111,2222,33333,44444';
    $bad = explode(',',$bad);
    usort($bad, function($a, $b) {
        return strlen($b) - strlen($a);
    });
    $strnew = strtolower($Input);
    $strnew = str_replace($bad,"<b>[censored]</b>",$strnew);
    if (strtolower($strnew) != strtolower($Input)) {
$msg = "Invalido";



$content = ['chat_id' => $chat_id, 'text' => $msg, 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
SendMessage($content);
      exit;
    }
    

$response = file_get_contents("https://hestiaccbot.alwaysdata.net/gen.php?lista=$Input");
$starttime = microtime(true);
$mytime = 'time1';
$cgen = "<code>$brand - $type - $bank - $country $emoji - $$currency</code>
<b><i>Execute Time {$mytime($starttime)}(s)</i></b>
$response";


$keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "Regenerate 🔄", "callback_data" => "gen"]
                ],
                [
                ["text" => "Delete 🗑️", "callback_data" => "del"]
            ]
        ]
    ]);
$content = ['chat_id' => $callbackchatid, 'message_id'=>$callbackmessageid , 'text' => $cgen, 'reply_to_message_id' => $callbackmessageid , 'reply_markup'=>$keyboard,'parse_mode' => "HTML"];
  EditMessageText($content);
    }
}
 
  if($data == "del"){
     if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => "Access denied opens another session to use it ❌", "show_alert" => true];
        answerCallbackQuery($content);
    } else {
$del = "<b><i>Seccion Ended By: <a href='tg://user?id=$callbackuserid'>$callbackusername</a></i></b>";
$content = ['chat_id' => $callbackchatid, 'message_id'=>$callbackmessageid , 'text' => $del, 'reply_to_message_id' => $callbackmessageid , 'reply_markup'=>$keyboard,'parse_mode' => "HTML"];
  EditMessageText($content);
    
    }
}

    