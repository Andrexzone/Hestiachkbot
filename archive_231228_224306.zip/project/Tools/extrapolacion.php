<?php
// Función principal que maneja el comando "extrap"
if (is_valid_command($text, array("extrap"))) {
    if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
autoRegisterUser($user_id, $username, $chat_id, $msg_id);
if (!get_authorize($chat_id, $msg_id)) {
        return;
}


    $keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "Support", "url" => "https://t.me/Team_HestiaChk"]
            ]
        ]
    ]);

    // Obtener la tarjeta del mensaje
    $tarjeta_original = extract_card_from_message($text);

    if (!$tarjeta_original) {
        // No se pudo extraer la tarjeta del mensaje, mostrar un mensaje de error
        $infoid = "No se pudo encontrar una tarjeta válida en el mensaje.";
    } else {
        // Realizar la extrapolación utilizando la tarjeta proporcionada por el usuario
        $infoid = extrapolate_card($tarjeta_original);
    }
    $starttime = microtime(true);
    $mytime = 'time1';
    $sql = "select * from administrar where id='$user_id'";
    $cs = mysqli_query(mysqlcon(),$sql);
    $raw = mysqli_fetch_assoc($cs);
    $title = $raw['rango'];
    $content = [
        'chat_id' => $chat_id,
        'text' => "$infoid\n<b>• Request By:  <i><a href='tg://user?id=$user_id'>$ufname</a></i> [$title]({$mytime($starttime)}s)</b>",
        'reply_to_message_id' => $msg_id,
        'reply_markup' => $keyboard,
        'parse_mode' => "HTML"
    ];

    sendMessage($content);
}

// Función para extraer la tarjeta del mensaje
function extract_card_from_message($message)
{
    // Lógica para extraer la tarjeta del mensaje
    // Puedes personalizar esto según el formato de tus mensajes
    $matches = [];
    if (preg_match('/(\d{16}|\d{4}\s\d{4}\s\d{4}\s\d{4}|\d{4}\|\d{2}\|\d{4}\|\d{3})/', $message, $matches)) {
        return $matches[0];
    }
    return false;
}

// Función para la extrapolación de tarjetas
function extrapolate_card($tarjeta)
{
    // Algoritmo de extrapolación avanzada
    $extrapolacion_basica = substr($tarjeta, 0, 6) . 'xxxxxxxxxx';
    $extrapolacion_clasica = substr($tarjeta, 0, 9) . 'xxxx';
    $extrapolacion_avanzada = substr($tarjeta, 0, 11) . 'xx' . substr($tarjeta, 13, 1) . 'x' . substr($tarjeta, 15, 1);

    // Formatear y devolver resultados
    $resultado = "<b><i>Extrapolation.</i></b>\n";
    $resultado .= "<b>• Card:</b> <code>$tarjeta</code>\n";
    $resultado .= "<b>• Basic:</b> <code>$extrapolacion_basica</code>\n";
    $resultado .= "<b>• Classic:</b> <code>$extrapolacion_clasica</code>\n";
    $resultado .= "<b>• Advanced:</b> <code>$extrapolacion_avanzada</code>";


    return $resultado;
}
?>
