<?php
require_once '/home/hestiaccbot/www/project/Resources/Functions.php';
if (is_valid_command($text, array("id"))) {
if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
$starttime = microtime(true);
$mytime = 'time1';
if(isset($r_uId)){
$u_idt = $r_uId;
}else{
$u_idt = $user_id;
}
$iboton = "Support And Owner";
$keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "$iboton", "url" => "https://t.me/Team_HestiaChk"]
            ]
        ]
    ]);
    
$infoid = "<b>➠User id:</b> <code>$u_idt</code>
<b>➠Chat id:</b> <code>$chat_id</code>";

$content = ['chat_id' => $chat_id, 'photo' => 'https://i.pinimg.com/564x/9c/97/22/9c972228c9b0e4447ac7863d953082a3.jpg', 'caption' => "$infoid", 'reply_to_message_id' => $msg_id, 'reply_markup' => $keyboard, 'parse_mode' => "HTML"];
sendphoto($content);

}
?>