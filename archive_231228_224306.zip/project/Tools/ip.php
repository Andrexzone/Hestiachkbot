<?php
// Verificar si se recibió el comando "/ip", "!ip", ".ip", "?ip" o "#ip"
if (is_valid_command($text, array("ip"))) {    
if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
autoRegisterUser($user_id, $username, $chat_id, $msg_id);
if (!get_authorize($chat_id, $msg_id)) {
        return;
}
$ip = substr($text, 4);

    // Verificar si se proporcionó una dirección IP
    if (empty($ip)) {
        $content = ['chat_id' => $chat_id, 'text' => "Error: Debes proporcionar una dirección IP válida.", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
        sendMessage($content);
    } else {
        // Obtener información sobre la dirección IP utilizando la API de ip-api.com
        $url = 'http://ip-api.com/json/' . $ip;
        $result = file_get_contents($url);

        if ($result === false) {
            $content = ['chat_id' => $chat_id, 'text' => "Error: No se pudo conectar a la API de ip-api.com.", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
            sendMessage($content);
        } else {
            $json = json_decode($result, true);

            if ($json === null || !isset($json['status']) || $json['status'] !== 'success') {
                $content = ['chat_id' => $chat_id, 'text' => "Error: No se pudo obtener la información de la dirección IP.", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
                sendMessage($content);
            } else {
                // Obtener los detalles de la dirección IP
                $country = $json['country'];
                $region = $json['regionName'];
                $city = $json['city'];
                $zip = $json['zip'];
                $isp = $json['isp'];

                // Mostrar los detalles de la dirección IP al usuario
                $content = ['chat_id' => $chat_id, 'text' => "Detalles de la dirección IP $ip:\nPaís: $country\nRegión: $region\nCiudad: $city\nZIP: $zip\nProveedor de servicios de Internet (ISP): $isp", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
                sendMessage($content);
            }
        }
    }
}

?>
