<?php

if (is_valid_command($text, array("xbin"))) {    
   if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
autoRegisterUser($user_id, $username, $chat_id, $msg_id);
if (!get_authorize($chat_id, $msg_id)) {
        return;
}
    $bins = explode(" ", trim($text)); // Separa los bins ingresados por espacio y elimina espacios adicionales al principio y al final
    //Verificar Usuario en la (DB)
    $sql = "SELECT * FROM administrar WHERE id='$user_id'";
    $cs = mysqli_query(mysqlcon(),$sql);
    $raw = mysqli_fetch_assoc($cs);
    $title = $raw['rango'];
    $plan = $raw['plan'];
    $SQL = "SELECT * FROM `administrar` WHERE `id`=".$user_id;
    $CONSULTA = mysqli_query(mysqlcon(),$SQL);
    $f = mysqli_num_rows($CONSULTA);

    // Filtrar los bins vacíos y contar la cantidad válida de bins
    $validBins = [];
    foreach ($bins as $bin) {
        $bin = preg_replace('/[^0-9]+/', '', $bin);
        $bin = substr($bin, 0, 6);

        if (is_numeric($bin)) {
            $validBins[] = $bin;
        }
    }

    // Verifica que haya entre 2 y 4 bins válidos ingresados
    $numValidBins = count($validBins);
    if ($numValidBins < 2 || $numValidBins > 4) {
        $content = ['chat_id' => $chat_id, 'text' => "<i>Ingresa entre 2 y 4 bins válidos separados por espacio.</i>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        SendMessage($content);
        exit();
    }

    $binInfoMessage = ""; // Variable para almacenar la información de los bins

    foreach ($validBins as $bin) {
        // Realizar la validación del bin y obtener la información
        $binInfo = json_decode(file_get_contents('https://bins.antipublic.cc/bins/'.$bin), true);

        if ($binInfo && isset($binInfo["level"])) {
            $level = $binInfo["level"];
            $type = $binInfo["type"];
            $brand = $binInfo["brand"];
            $country = $binInfo["country_name"];
            $currency = $binInfo["country_currencies"][0];
            $bank = $binInfo["bank"];
            $emoji = $binInfo["country_flag"];

            // Agregar la información del bin actual a la variable $binInfoMessage
            // utilizando la concatenación de cadenas (.=)
            $binInfoMessage .= "━ • ━━━━━━━━━━━━ • ━\nBin -» <code>$bin</code>\n";
            $binInfoMessage .= "Bin Info -» <i>$level ~ $brand ~ $type</i>\n";
            $binInfoMessage .= "Bank -» <i>$bank $currency💱</i>\n";
            $binInfoMessage .= "Country -» <b>$country [$emoji]</b>\n";
        } else {
            // Si no se pudo obtener información del bin, mostrar un mensaje de error en la variable $binInfoMessage
            $binInfoMessage .= "━ • ━━━━━━━━━━━━ • ━\nNo se pudo obtener información del bin: $bin\n";
        }
    }

    //time Code.
    $starttime = microtime(true);
    $mytime = 'time1';
    $timest = time();
    // Envía el mensaje con la información de los bins
    $message = "<b>Mass Bin Lookup! ♻️</b>
$binInfoMessage ━ • ━━━━━━━━━━━━ • ━
Took -» <i>{$mytime($starttime)}'s</i>
user -» <b>$username1 ⌞ $title ⌝</b>
Made By -» <i>@Jannyex</i>";
    $content = ['chat_id' => $chat_id, 'text' => $message,  'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
    SendMessage($content);
}
