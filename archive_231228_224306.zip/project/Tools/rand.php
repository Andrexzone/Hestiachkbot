<?php
// Verificar si se recibió el comando "/rnd", "!rnd", ".rnd", "?rnd" o "#rnd"
if (is_valid_command($text, array("rnd"))) {    
    if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
autoRegisterUser($user_id, $username, $chat_id, $msg_id);
if (!get_authorize($chat_id, $msg_id)) {
        return;
}
    $country = substr($text, 5, 7);

    // Verificar si el país está en la lista de países permitidos
    $allowed_countries = ["AU", "BR", "CA", "CH", "DE", "DK", "ES", "FI", "FR", "GB", "IE", "IR", "NO", "NL", "NZ", "TR", "US"];
    if (!in_array($country, $allowed_countries)) {
        $content = ['chat_id' => $chat_id, 'text' => "Error: <i>Tu Pais No esta en la lista de disponibles.</i>
Disponible -» <i>BR, AU, CA, CH, DE, DK, ES FI , FR, GB, IE, IR, NO, NL, NZ, TR, US</i>", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
        sendMessage($content);
    } else {
        // Obtener información aleatoria para el país especificado utilizando la API de randomuser.me
        $url = "https://randomuser.me/api/?nat=$country&inc=name,location,email,dob,phone,picture";
        $result = file_get_contents($url);

        if ($result === false) {
            $content = ['chat_id' => $chat_id, 'text' => "Error: No se pudo conectar a la API de randomuser.me.", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
            sendMessage($content);
        } else {
            $json = json_decode($result, true);

            if ($json === null || !isset($json['results'][0])) {
                $content = ['chat_id' => $chat_id, 'text' => "Error: No se pudo obtener la información aleatoria.", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
                sendMessage($content);
            } else {
                // Obtener los detalles de la información aleatoria
                $user = $json['results'][0];

                // Mostrar los detalles de la información aleatoria al usuario
                $content = ['chat_id' => $chat_id, 'photo' => "{$user['picture']['large']}", 'caption' => "<b><i>Información aleatoria para $country</i>♻️</b>
Nombre: <code>{$user['name']['first']} {$user['name']['last']}</code>
<b><i>⚾ Ubicación:</i></b>
Calle: <code>{$user['location']['street']['name']}</code>, <code>{$user['location']['street']['number']}</code>
Ciudad: <code>{$user['location']['city']}</code>
Estado/Provincia: <code>{$user['location']['state']}</code>
Código postal: <code>{$user['location']['postcode']}</code>
País: <code>{$user['location']['country']}</code>
Correo electrónico: <code>{$user['email']}</code>
Fecha de nacimiento: <code>{$user['dob']['date']}</code>
Teléfono: <code>{$user['phone']}</code>
Imagen del perfil: {$user['picture']['large']}
Made By -» <i>@Jannyex</i>", 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
                sendphoto($content);
            }
        }
    }
}

