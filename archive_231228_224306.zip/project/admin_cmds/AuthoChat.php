<?php
if (is_valid_command($text, array("cadd"))) {
    // Verifica si el usuario tiene permiso para encender el bot
    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner', 'admin'])) {
        // El usuario no tiene permiso para encender el bot
        return;
    }

    $listak = substr($text, 6);
    $i = explode("|", $listak);

    if (count($i) !== 2) {
        SendMessage(['chat_id' => $chat_id, 'text' => '<b>Format⇾</b> <code>Group ID|Days.</code>', 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html']);
        return;
    }

    $auth = $i[0];
    $day = $i[1];
    $expiry = time() + ($day * 86400);
    $pi = date('l jS \of F Y', $expiry);

    $sql = "SELECT * FROM `authorize` WHERE chats = '$auth'";
    $consulta = mysqli_query(mysqlcon(), $sql);
    $f = mysqli_num_rows($consulta);

    if ($f > 0) {
        SendMessage(['chat_id' => $chat_id, 'text' => 'Group already authorized.']);
    } else {
        $sql = "INSERT INTO `authorize`(`chats`, `planexpiry`) VALUES ('$auth', '$expiry')";
        $cs = mysqli_query(mysqlcon(), $sql);

        $message = "⇾ <i>Chat Succefull Added 🎁️</i>\n";
        $message .= "⇾ Status: <b>Premium</b>\n";
        $message .= "⇾ Expires In: $pi";

        SendMessage(['chat_id' => $chat_id, 'text' => $message, 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html']);
    }
}

if (is_valid_command($text, array("cdel"))) {
    // Verifica si el usuario tiene permiso para encender el bot
    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner', 'admin'])) {
        // El usuario no tiene permiso para encender el bot
        return;
    }
    $auth = explode(" ", $text)[1];
    $SQL = "SELECT * FROM `authorize` WHERE chats=".$auth;
    $CONSULTA = mysqli_query(mysqlcon(),$SQL);
    $f = mysqli_num_rows($CONSULTA);
        $SQL = "DELETE FROM authorize WHERE `authorize`.`chats` = '$auth'";
        $cs = mysqli_query(mysqlcon(),$SQL);
        $content = ['chat_id' => $chat_id, 'text' => "<b>[ ⚠️ ] Chat Demote successfully</b>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        $m1  = SendMessage($content);
    
}


?>
