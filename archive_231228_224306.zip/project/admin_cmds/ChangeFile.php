<?php
if (is_valid_command($text, array("test"))) {    
    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner', 'admin'])) {
        exit();
    }
    
    $parts = explode('~', substr($text, 6)); // Cambia el delimitador a "~"
    if (count($parts) == 3) {
        $file_name = trim($parts[0]);
        $variable_name = trim($parts[1]);
        $new_content = trim($parts[2]);

        $file_path = '/home/hestiaccbot/www/project/' . $file_name;
        
        // Verificar si el archivo existe antes de abrirlo
        if (file_exists($file_path)) {
            $lines = file($file_path);
            $variable_name = '$' . $variable_name;
            foreach ($lines as $key => $line) {
                if (strpos($line, $variable_name) !== false) {
                    $lines[$key] = $variable_name . ' = "' . $new_content . '";' . PHP_EOL;
                    break;
                }
            }
            $file = fopen($file_path, 'w');
            if ($file) {
                fwrite($file, implode('', $lines));
                fclose($file);

                // Envía un mensaje confirmando la edición exitosa
                $content = ['chat_id' => $chat_id, 'text' => "<i>La variable: <code>$variable_name</code>, en el archivo <code>$file_name</code> se ha editado correctamente.</i>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
                SendMessage($content);
            } else {
                // Envía un mensaje si no se pudo abrir el archivo en modo escritura
                $content = ['chat_id' => $chat_id, 'text' => "Ha ocurrido un error al abrir el archivo en modo escritura.", 'reply_to_message_id' => $msg_id];
                SendMessage($content);
            }
        } else {
            // Envía un mensaje si el archivo no existe
            $content = ['chat_id' => $chat_id, 'text' => "El archivo <code>$file_name</code> no existe en la ubicación especificada.", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
            SendMessage($content);
        }
    } else {
        // Envía un mensaje si el comando se proporciona incorrectamente
        $content = ['chat_id' => $chat_id, 'text' => "El formato del comando es incorrecto. Debes usar /test carpeta/archivo~nombre_variable~nuevo_contenido", 'reply_to_message_id' => $msg_id];
        SendMessage($content);
    }
}
