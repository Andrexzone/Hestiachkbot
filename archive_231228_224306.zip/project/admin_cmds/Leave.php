<?php
if (is_valid_command($text, array("leave"))) {    
    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner'])) {
        exit();
    }

    $leave_message = substr($text, 7);

    // Envía el mensaje de salida
    if (!empty($leave_message)) {
        $content = ['chat_id' => $chat_id, 'text' => $leave_message];
        SendMessage($content);
    }

    // Abandona el chat
    LeaveChat(['chat_id' => $chat_id]);
}
