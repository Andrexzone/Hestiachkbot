<?php

if (is_valid_command($text, array("addstaff"))) {
    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner'])) {
        exit();
    }

    $parts = explode(' ', $text);
    if (count($parts) == 3) {
        $new_user_id = $parts[1];
        $new_user_rank = $parts[2];
$db = mysqli_connect('mysql-hestiaccbot.alwaysdata.net', '341157', 'andresone1', 'hestiaccbot_455');
        // Prepara y ejecuta una consulta para insertar el nuevo usuario en la base de datos
        $stmt = $db->prepare('INSERT INTO users (id, rank) VALUES (?, ?)');
        $stmt->bind_param('ss', $new_user_id, $new_user_rank);
        $stmt->execute();

        // Envía un mensaje confirmando que el usuario ha sido agregado
        $content = ['chat_id' => $chat_id, 'text' => "El usuario con ID <code>$new_user_id</code> ha sido agregado como <code>$new_user_rank</code>.", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        SendMessage($content);
    } else {
        // Envía un mensaje si el comando se proporciona incorrectamente
        $content = ['chat_id' => $chat_id, 'text' => "El formato del comando es incorrecto. Debes usar /adduser user_id rank", 'reply_to_message_id' => $msg_id];
        SendMessage($content);
    }
}

if (is_valid_command($text, array("removeuser"))) {
    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner'])) {
        exit();
    }

    $parts = explode(' ', $text);
    if (count($parts) == 2) {
        $remove_user_id = $parts[1];
$db = mysqli_connect('mysql-hestiaccbot.alwaysdata.net', '341157', 'andresone1', 'hestiaccbot_455');
        $stmt = $db->prepare('DELETE FROM users WHERE id = ?');
        $stmt->bind_param('s', $remove_user_id);
        $stmt->execute();

        // Envía un mensaje confirmando que el usuario ha sido eliminado
        $content = ['chat_id' => $chat_id, 'text' => "El usuario con ID <code>$remove_user_id</code> ha sido eliminado.", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        SendMessage($content);
    } else {
        // Envía un mensaje si el comando se proporciona incorrectamente
        $content = ['chat_id' => $chat_id, 'text' => "El formato del comando es incorrecto. Debes usar /removeuser user_id", 'reply_to_message_id' => $msg_id];
        SendMessage($content);
    }
}


if (is_valid_command($text, array("listuser"))) {

    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner'])) {
        exit();
    }

    $parts = explode(' ', $text);
    if (count($parts) == 2) {
        $list_rank = $parts[1];

        // Conéctate a la base de datos
$db = mysqli_connect('mysql-hestiaccbot.alwaysdata.net', '341157', 'andresone1', 'hestiaccbot_455');
        // Prepara y ejecuta una consulta para recuperar los usuarios con el rango especificado
        $stmt = $db->prepare('SELECT id FROM users WHERE rank = ?');
        $stmt->bind_param('s', $list_rank);
        $stmt->execute();
        $result = $stmt->get_result();

        // Crea una lista de usuarios
        $users_list = '';
        while ($row = $result->fetch_assoc()) {
            $users_list .= "• Rango: <i>$list_rank</i> | <code>{$row['id']}</code>\n";
        }

        // Envía un mensaje con la lista de usuarios
        if (!empty($users_list)) {
            $content = ['chat_id' => $chat_id, 'text' => "Usuarios con rango <code>$list_rank</code>:\n$users_list", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
            SendMessage($content);
        } else {
            $content = ['chat_id' => $chat_id, 'text' => "No hay usuarios con rango <code>$list_rank</code>.", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
            SendMessage($content);
        }
    } else {
        // Envía un mensaje si el comando se proporciona incorrectamente
        $content = ['chat_id' => $chat_id, 'text' => "El formato del comando es incorrecto. Debes usar /listusers rank", 'reply_to_message_id' => $msg_id];
        SendMessage($content);
    }
}

