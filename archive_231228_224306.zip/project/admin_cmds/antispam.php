<?php
if (is_valid_command($text, array("antispam"))) {    
    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner'])) {
        exit();
    }
    
$mensaje = substr($text, 10);
$i = explode(' ', $mensaje);
$antispam = $i[0];
$userId = $i[1];


if(empty($mensaje)){
         $m = "<i>Invalid Message [❌]</i>
<b>- - - - - - - - - - - - - - - - - - - - -
Ex: <code>/antispam 1s UserID</code>
- - - - - - - - - - - - - - - - - - - - -
Tip: <i>define the seconds with - s - for example 30s = 30 Seconds</i></b>";
        $content = ['chat_id' => $chat_id, 'text' => "$m", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
         SendMessage($content);
         exit;
}


$sqli = "SELECT * FROM `administrar` WHERE id = '$userId'";
$con = mysqli_query(mysqlcon(), $sqli);
$filas = mysqli_num_rows($con);
if($filas > 0){
       
}else{
       $m = "<i>I couldn't find the user ID in my registration list!</i>";
        $content = ['chat_id' => $chat_id, 'text' => "$m", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
         SendMessage($content);
         exit;
}

    if(stripos($antispam,'s')){
            $segundos = segundosAntispam(time(),$antispam);
          }

$sql = "UPDATE `administrar` SET `antispam2`='$antispam' WHERE id='$userId'";
$consultar = mysqli_query(mysqlcon(), $sql);

       $m = "<b><i>Succes Added [✅]</i>
- - - - - - - - - - - - - - - - - - - - -
ID: $userId
AntiSpam: $antispam
- - - - - - - - - - - - - - - - - - - - -</b>";
        $content = ['chat_id' => $chat_id, 'text' => "$m", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
         SendMessage($content);
    }
    
    
