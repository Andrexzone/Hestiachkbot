<?php
// Conéctate a la base de datos
$db = mysqli_connect('mysql-hestiaccbot.alwaysdata.net', '341157', 'andresone1', 'hestiaccbot_455');

if (is_valid_command($text, array("boton"))) {
    // Verifica si el usuario tiene permiso para encender el bot
  /*  if (!hasPermission($user_id, $chat_id, $msg_id, ['owner', 'admin'])) {
        // El usuario no tiene permiso para encender el bot
        return;
    }*/
    
    // Actualiza el estado del bot en la base de datos
    mysqli_query($db, 'UPDATE bot_status SET status = 1');

    // Envía un mensaje de confirmación
    $content = ['chat_id' => $chat_id, 'text' => "<i>El bot ha sido encendido.</i>", 'reply_to_message_id' => $msg_id];
    SendMessage($content);
}

if (is_valid_command($text, array("botoff"))) {
    // Verifica si el usuario tiene permiso para apagar el bot
    /*if (!hasPermission($user_id, $chat_id, $msg_id, ['owner', 'admin'])) {
        // El usuario no tiene permiso para apagar el bot
        return;
    }*/

    // Actualiza el estado del bot en la base de datos
    mysqli_query($db, 'UPDATE bot_status SET status = 0');

    // Envía un mensaje de confirmación
    $content = ['chat_id' => $chat_id, 'text' => "El bot ha sido apagado.", 'reply_to_message_id' => $msg_id];
    SendMessage($content);
}