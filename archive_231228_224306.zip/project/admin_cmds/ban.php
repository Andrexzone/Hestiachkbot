<?php
if (is_valid_command($text, array("ban"))) {    
    $conn = mysqlcon();
    if (!$conn) {
        $content = ['chat_id' => $chat_id, 'text' => "Error: No se pudo conectar a la base de datos.", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        SendMessage($content);
        die;
    }

    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner'])) {
        exit();
    }

    // Obtener el ID del usuario que se va a banear y la razón
    if (preg_match('/\/ban\s+(\d+)\s+(.+)/', $text, $matches)) {
        // Si se proporcionó el ID y la razón directamente en el comando
        $user = $matches[1];
        $reason = $matches[2];
    } elseif (isset($message['reply_to_message'])) {
        // Si se respondió a un mensaje y no se proporcionó el ID y la razón directamente en el comando
        $user = $message['reply_to_message']['from']['id'];
        $reason = substr($text, strlen('/ban') + 1); // +1 para ignorar el espacio después del comando
    } else {
        // Si no se proporcionó el ID y la razón directamente en el comando ni se respondió a un mensaje
        $msg = "<b>⚠️ Debes proporcionar el ID del usuario y la razón por la que deseas banearlo, o responder a un mensaje del usuario para banearlo.</b>";
        $content = ['chat_id' => $chat_id, 'text' => $msg, 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
        SendMessage($content);
        die;
    }

    // Verificar si el usuario ya está baneado
    $sql = "SELECT * FROM banned_users WHERE user_id='$user'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        // Si el usuario ya está baneado, enviar un mensaje indicando que no se puede banear nuevamente
        $msg = "<b>⚠️ El usuario con ID $userid ya está baneado y no puede ser baneado nuevamente.</b>";
        $content = ['chat_id' => $chat_id, 'reply_to_message_id' => $msg_id, 'text' => $msg, 'parse_mode' => "HTML"];
        SendMessage($content);
        mysqli_close($conn);
        die;
    }

    // Registrar el ban en la base de datos
    $timestamp = date('Y-m-d H:i:s');
    $sql = "INSERT INTO banned_users (user_id, reason, timestamp) VALUES ('$user', '$reason', '$timestamp')";
    mysqli_query($conn, $sql);

    // Enviar un mensaje confirmando el ban
    $msg = "<b>El usuario con ID $user ha sido baneado por la siguiente razón: $reason.♻️</b>";
    $content = ['chat_id' => $chat_id, 'reply_to_message_id' => $msg_id, 'text' => $msg, 'parse_mode' => "HTML"];
    SendMessage($content);

    mysqli_close($conn);
}



// Comando para desbanear a un usuario
if (is_valid_command($text, array("unban"))) {    
    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner'])) {
        exit();
    }
    // Obtener el ID del usuario que se va a desbanear
    if (preg_match('/\/unban\s+(\d+)/', $text, $matches)) {
        // Si se proporcionó el ID directamente en el comando
        $userid = $matches[1];
    } elseif (isset($message['reply_to_message']['from']['id'])) {
        // Si se respondió a un mensaje y no se proporcionó el ID directamente en el comando
        $userid= $message['reply_to_message']['from']['id'];
    } else {
        // Si no se proporcionó el ID directamente en el comando ni se respondió a un mensaje
        $msg = "<b>⚠️ You must provide the user ID you want to unban, or reply to a message of a banned user to unban it.</b>";
        $content = ['chat_id' => $chat_id, 'text' => $msg, 'reply_to_message_id' => $msg_id, 'parse_mode' => "HTML"];
        SendMessage($content);
        return;
    }

    // Verificar si el usuario está en la lista de usuarios baneados
    $sql = "SELECT * FROM banned_users WHERE user_id='$userid' LIMIT 1";
    $result = mysqli_query(mysqlcon(), $sql);
    if (mysqli_num_rows($result) == 0) {
        // Si el usuario no está en la lista de usuarios baneados
        $msg = "<b>⚠️ The user with ID $user_id is not banned.</b>";
        $content = ['chat_id' => $chat_id, 'reply_to_message_id' => $msg_id, 'text' => $msg, 'parse_mode' => "HTML"];
        SendMessage($content);
        return;
    }

    // Eliminar el registro del ban de la base de datos
    $sql = "DELETE FROM banned_users WHERE user_id='$userid'";
    mysqli_query(mysqlcon(), $sql);

    // Enviar un mensaje confirmando el deban
    $msg = "<b>The user with ID $userid has been unbanned.🎉</b>";
    $content = ['chat_id' => $chat_id, 'reply_to_message_id' => $msg_id, 'text' => $msg, 'parse_mode' => "HTML"];
    SendMessage($content);
}
?>


