<?php

if (is_valid_command($text, array("key"))) {
    // Verifica si el usuario tiene permiso para encender el bot
    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner', 'admin'])) {
        // El usuario no tiene permiso para encender el bot
        return;
    }

    $fecha_actual = date('Y-m-d H:i');
    $channel_id = '-1002126213403';

    $listak = substr($text, 5);
    $i = explode("|", $listak);
    $plantype = !empty($i[0]) ? strtoupper($i[0]) : "P";
    $expiry = !empty($i[1]) ? $i[1] : 0;
    $spam = !empty($i[2]) ? strtoupper($i[2]) : "DEFAULT_VALUE";
    $title = !empty($i[3]) ? strtoupper($i[3]) : "DEFAULT_VALUE";
    $credits = !empty($i[4]) ? strtoupper($i[4]) : "DEFAULT_VALUE";
    $expiry_in_seconds = $expiry * 86400;
    $now = time();
    $expiry_timestamp = $now + $expiry_in_seconds;
    
    if(empty ($expiry)){
    $content = ['chat_id' => $chat_id, 'text' => "Forbidden: <b>[Fill the Exhalation field]⛈</b>", 'reply_to_message_id' => $msg_id, 'reply_markup' => $keyboard, 'parse_mode' => 'html'];
    SendMessage($content);
    exit();
    }
    if(empty ($title)){
    $content = ['chat_id' => $chat_id, 'text' => "Forbidden: <b>[Fill the title field]⛈</b>", 'reply_to_message_id' => $msg_id, 'reply_markup' => $keyboard, 'parse_mode' => 'html'];
    SendMessage($content);
    exit();
    }
    if(empty ($spam)){
    $content = ['chat_id' => $chat_id, 'text' => "Forbidden: <b>[Fill the Antispam field]⛈</b>", 'reply_to_message_id' => $msg_id, 'reply_markup' => $keyboard, 'parse_mode' => 'html'];
    SendMessage($content);
    exit();
    }
    if(empty ($credits)){
    $content = ['chat_id' => $chat_id, 'text' => "Forbidden: <b[Fill in the Credits field]⛈</b>", 'reply_to_message_id' => $msg_id, 'reply_markup' => $keyboard, 'parse_mode' => 'html'];
    SendMessage($content);
    exit();
    }

    function RandomString($length = 4) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    if ($plantype == "P") {
        $plantype = "Premium";
    } elseif ($plantype == "V") {
        $plantype = "Vip User";
    }

    $two = RandomString();
    $three = RandomString();
    $four = RandomString();
    $five = RandomString();
    $six = RandomString();
    $key = 'Hestia-' . $two . '' . $three . '' . $four . ''.$five.''.$six.'-key';

    // Insertar en la base de datos
    $SQL = "INSERT INTO nick (nick, status, plan, planexpiry, spam, title, creditos) VALUES ('$key', 'ACTIVE', '$plantype', '$expiry_timestamp', '$spam', '$title', '$credits')";
    if (mysqli_query(mysqlcon(), $SQL)) {
        // Obtener la fecha de expiración en formato legible
        $expiry_date_formatted = date('d M Y H:i', $expiry_timestamp);

    // Calcular la diferencia entre la fecha actual y la fecha de expiración
    $now = time();
    $diff_seconds = $expiry_timestamp - $now;
    $days = floor($diff_seconds / (60 * 60 * 24));
    $hours = floor(($diff_seconds % (60 * 60 * 24)) / (60 * 60));
    $minutes = floor(($diff_seconds % (60 * 60)) / 60);
    $seconds = $diff_seconds % 60;
    
        // Crear el mensaje de respuesta con los detalles de la clave y la duración restante
       $message = "<b>[✅] Key Premium Generada </b>🪬\n━ ━ ━ ━ ━ ━ ━ ━━ ━ ━\n";
        $message .= "↳ <b>Key:</b> <code>$key</code>\n";
        $message .= "↳ <b>Plan:</b> $plantype\n";
        $message .= "↳ <b>Vigencia:</b> $days días, $hours horas, $minutes minutos y $seconds segundos\n";
        $message .= "↳ <b>Fecha de Expiración:</b> <i>$expiry_date_formatted</i>\n";
        $message .= "↳ <b>Antispam:</b> $spam\n";
        $message .= "↳ <b>Credits:</b> $credits\n";
        $message .= "↳ <b>Apodo:</b> $title\n━ ━ ━ ━ ━ ━\n";
        $message .= "↳ <b>Usa:</b> /claim para reclamar <code>$key</code>\n";
        $message .= "↳ <b>Hecho Por: <i><a href='https://t.me/Team_HestiaChk'>𝑿/𝒛</a></i></b>";

        $content = ['chat_id' => $chat_id, 'text' => $message, 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        $m1 = SendMessage($content);

        // Enviar mensaje al canal con la información de la clave creada        
        $content = ['chat_id' => $channel_id, 'photo' => "https://cdn.donmai.us/original/93/a8/93a89b90753dfdceab26c33bc6e344e5.jpg", 'caption' => "<i>Key Creada Y encontrada!</i>\nKey: <code>$key</code>\nAntispam: <code>$spam</code>\nTitle: <i>$title</i>\nCreada Por: <b>$username1</b> (<code>$user_id</code>)\nFecha: <i>$expiry_date_formatted</i>", 'parse_mode' => 'html'];
        sendphoto($content);
    } else {
        $error_message = mysqli_error(mysqlcon());
        $content = ['chat_id' => $chat_id, 'text' => "Ha ocurrido un error al generar la clave:\n$error_message", 'reply_to_message_id' => $msg_id];
        SendMessage($content);
    }
}

