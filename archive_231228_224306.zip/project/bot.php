<?php
require_once 'requires.php';
require_once '/home/hestiaccbot/www/project/data/data.php';
require_once '/home/hestiaccbot/www/project/Resources/Functions.php';

if (is_valid_command($text, array("start"))) {   
    if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
autoRegisterUser($user_id, $username, $chat_id, $msg_id);

if (!get_authorize($chat_id, $msg_id)) {
        return;
}
if (!check_authorization_and_plan($user_id, $msg_id)) {
        return;
}


$keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "$sboton2", "url" => "https://t.me/Team_HestiaChk"],
                ["text" => "$sboton", "url" => "https://t.me/Team_HestiaChk"]
            ],
            [
                ["text" => "$sboton1", "url" => "https://t.me/Hinatachkbot?startgroup=true"],
                ["text" => "$sboton3", "url" => "https://t.me/refes_hestia"]
             
            ]
        ]
    ]);
    
    /*$sticker_id = "CAACAgQAAxkBAAEOxFtk0tczqqn-xAFpqQoy5VU9HdetOwACDAAEJmgcXW045s8-1WIwBA";

    $content = ['chat_id' => $chat_id, 'sticker' => $sticker_id];
    sendSticker($content); */ 
    sendChatAction(['chat_id' => $chat_id, 'action' => "typing"]);

    $content = ['chat_id' => $chat_id, 'photo' => "https://i.pinimg.com/564x/3c/25/c9/3c25c971df6d412f61023e1467392a01.jpg", 'caption' => "$start", 'reply_to_message_id' => $msg_id, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
    $m3 = sendphoto($content);
}


/* Command intended for owner to view administrative commands 
if (is_valid_command($text, array("andy"))) {
    if (!hasPermission($user_id, $chat_id, $msg_id, ['owner', 'admin'])) {
        return;
    }
    if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}

date_default_timezone_set('America/Bogota'); 
$hora_actual = date('H'); 
if ($hora_actual >= 5 && $hora_actual < 12) {
    $saludo = "Good morning! 🌇"; // Buenos días
} elseif ($hora_actual >= 12 && $hora_actual < 18) {
    $saludo = "Good afternoon! 🏞"; // Buenas tardes
} else {
    $saludo = "Good evening! 🌃"; // Buenas noches
}
$sql = "select * from administrar where id='$user_id'";
$cs = mysqli_query(mysqlcon(),$sql);
$raw = mysqli_fetch_assoc($cs);
$planexpiry = $raw['planexpiry'];
$credits = $raw['creditos'];
$plan = $raw['plan'];
$title = $raw['rango'];

    $keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "Apagar", "callback_data" => "apagar"],
                ["text" => "Extras", "callback_data" => "tools"],
                ["text" => "Promote", "callback_data" => "info"]
            ],
            [
                ["text" => "Exit 🎄", "callback_data" => "exit"]
            ],
            [
                ["text" => "Support", "url" => "https://t.me/Team_HestiaChk"]
            ]
        ]
    ]);

    $content = ['chat_id' => $chat_id,'photo'=> 'https://i.pinimg.com/564x/09/87/e0/0987e08761f8e130566b3a64d7cddfa5.jpg','caption' => "<i>Hello $username1 ($title), $saludo This command is designed to help you use the commands well, you can use the buttons that appear below</i>", 'reply_markup' => $keyboard, 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
    sendphoto($content);
}

if ($data == "atra" || $data == "retu") {
    if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
        date_default_timezone_set('America/Bogota'); 
$hora_actual = date('H'); 
if ($hora_actual >= 5 && $hora_actual < 12) {
    $saludo = "Good morning! 🌇"; // Buenos días
} elseif ($hora_actual >= 12 && $hora_actual < 18) {
    $saludo = "Good afternoon! 🏞"; // Buenas tardes
} else {
    $saludo = "Good evening! 🌃"; // Buenas noches
}
$sql = "select * from administrar where id='$callbackuserid'";
$cs = mysqli_query(mysqlcon(),$sql);
$raw = mysqli_fetch_assoc($cs);
$planexpiry = $raw['planexpiry'];
$credits = $raw['creditos'];
$plan = $raw['plan'];
$title = $raw['rango'];
    } else {   
    $keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "Apagar", "callback_data" => "apagar"],
                ["text" => "Extras", "callback_data" => "tools"],
                ["text" => "Promote", "callback_data" => "info"]
            ],
            [
                ["text" => "Exit 🎄", "callback_data" => "exit"]
            ],
            [
                ["text" => "Support", "url" => "https://t.me/Team_HestiaChk"]
            ]
        ]
    ]);



$content = ['chat_id' => $callbackchatid,'video'=> 'mikazausers.alwaysdata.net/project/start.mp4','caption' => "<i>Hello @$callbackusername ($title), $saludo This command is designed to help you use the commands well, you can use the buttons that appear below</i>", 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditCaption($content);
    }
}


if ($data == "apagar") {
    if ($callbackfrom != $callbackuserid) {        
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
    } else {
        $keyboard = json_encode([
            "inline_keyboard" => [
                [
                    ["text" => "🏡 Home", "callback_data" => "atra"]
 
                ]
            ]
        ]);
        $off = "<b><i>Command (Admins) Seccion Apagar Bot!</i>
- - - - - - - - - - - - - - - - - - - - -</b>
Command: <code>$botoff</code> <b>[ Owner 🔥 ]</b>
Alive: <b>[ ON ✅ ]</b>
Comment: <b>Use this command to Turn OFF the bot in case it is not working Good only For Owner</b>
<b>- - - - - - - - - - - - - - - - - - - - -</b>
Command: <code>$boton</code> [ Owner 🔥 ]
Alive: [ ON ✅ ]
Comment: <b>Use this command to Turn ON the bot in case it is not working Good only For Owner</b>";
        $content = ['chat_id' => $callbackchatid,'photo'=> 'xtrachkbot.alwaysdata.net/project/th.jpeg','caption' => $off, 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditCaption($content);
    }
}
*/
/* This is the code that is executed when the user sends the command `/cmds` or `.cmds` or `?cmds` or `#cmds` or `/cmds@` to the bot. */
if (is_valid_command($text, array("cmds"))) {
    if (!checkBotStatus($chat_id, $msg_id)) {
    return;
}
if (!isUserAllowed($user_id, $chat_id, $msg_id)) {
    return;
}
autoRegisterUser($user_id, $username, $chat_id, $msg_id);

if (!get_authorize($chat_id, $msg_id)) {
        return;
}
if (!check_authorization_and_plan($user_id, $msg_id)) {
        return;
}
    $keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "$cboton", "callback_data" => "gates"],
                ["text" => "$cboton1", "callback_data" => "tools"],
                ["text" => "$cboton2", "callback_data" => "info"]
            ],
            [
                ["text" => "$cboton3", "callback_data" => "exit"]
            ],
            [
                ["text" => "$cboton4", "url" => "https://t.me/TeamAlpha_ofc/4"]
            ]
        ]
    ]);

    $content = ['chat_id' => $chat_id,'photo'=> 'https://i.pinimg.com/564x/12/ed/ed/12eded458e67e4a43891050502441652.jpg','caption' => "$principalcmds", 'reply_markup' => $keyboard, 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
    $m1 = sendphoto($content);
}


/* This is the code that is executed when the user clicks on the "Return" button. */
if ($data == "home" || $data == "return") {
    if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
    } else {   
    $keyboard = json_encode([
        "inline_keyboard" => [
            [
                ["text" => "$cboton", "callback_data" => "gates"],
                ["text" => "$cboton1", "callback_data" => "tools"],
                ["text" => "$cboton2", "callback_data" => "info"]
            ],
            [
                ["text" => "$cboton3", "callback_data" => "exit"]
            ],
            [
                ["text" => "$cboton4", "url" => "https://t.me/Jannyex"]
            ]
        ]
    ]);



$content = ['chat_id' => $callbackchatid,'video'=> 'mikazausers.alwaysdata.net/project/start.mp4','caption' => "$homecmds", 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditCaption($content);
    }
}


/* This is the code that is executed when the user clicks on the "Gates" button. */
if ($data == "gates") {
    if ($callbackfrom != $callbackuserid) {        
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
    } else {
        $keyboard = json_encode([
            "inline_keyboard" => [
                [
                    ["text" => "Charge", "callback_data" => "charge"],
                    ["text" => "Auth", "callback_data" => "auth"],
                    ["text" => "Mass", "callback_data" => "mass"],
                ],
                [
                    ["text" => "🏡 Home", "callback_data" => "home"],
                   // ["text" => "𝗖𝗹𝗼𝘀𝗲", "callback_data" => "end"]
                ]
            ]
        ]);

        $content = ['chat_id' => $callbackchatid,'photo'=> 'xtrachkbot.alwaysdata.net/project/th.jpeg','caption' => "$gates", 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditCaption($content);
    }
}

/* This is the code that is executed when the user clicks on the "Gates Charge" button. */
if ($data == "charge") {
    if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
    } else {
        $keyboard = json_encode([
            "inline_keyboard" => [
                [
                    ["text" => "Previous", "callback_data" => "gates"],
                  //  ["text" => "Next", "callback_data" => "charge2"],
                ]
            ]
        ]);

        /*$content = ['chat_id' => $callbackchatid, 'text' => $charge, 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditMessageText($content);*/
        $content = ['chat_id' => $callbackchatid,'photo'=> 'xtrachkbot.alwaysdata.net/project/th.jpeg','caption' => $charge, 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditCaption($content);
    }
}

/* This is the code that is executed when the user clicks on the "Gates Auth" button. */
if ($data == "auth") {
    if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
    } else {
        $keyboard = json_encode([
            "inline_keyboard" => [
                [
                    ["text" => "Previous", "callback_data" => "gates"],
         //           ["text" => "Home", "callback_data" => "home"],
                ]
            ]
        ]);


$content = ['chat_id' => $callbackchatid,'photo'=> 'xtrachkbot.alwaysdata.net/project/th.jpeg','caption' => $auth, 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditCaption($content);
    }
}


if ($data == "mass") {
    if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
    } else {
        $keyboard = json_encode([
            "inline_keyboard" => [
                [
                    ["text" => "Previous", "callback_data" => "gates"],
                  //  ["text" => "", "callback_data" => "auth"],
                  //  ["text" => "Home", "callback_data" => "return"],
                ]
            ]
        ]);

        
$content = ['chat_id' => $callbackchatid,'photo'=> 'xtrachkbot.alwaysdata.net/project/th.jpeg','caption' => $masive, 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditCaption($content);
    }
}


/* This is the code that is executed when the user clicks on the "3D Check" button. */
if ($data == "tools1") {
    if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
    } else {
        $keyboard = json_encode([
            "inline_keyboard" => [
                [
                    ["text" => "Return", "callback_data" => "tools"]
                ]
            ]
        ]);

        /*$content = [
            'chat_id' => $callbackchatid,
            'text' => $gates3d,
            'message_id' => $callbackmessageid,
            'reply_markup' => $keyboard,
            'parse_mode' => 'HTML'
        ];*/
$content = ['chat_id' => $callbackchatid,'photo'=> 'xtrachkbot.alwaysdata.net/project/th.jpeg','caption' => $tools, 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditCaption($content);
        
    }
}


/* This is the code that is executed when the user clicks on the "Tools" button. */
if ($data == "tools") {
    if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
    } else {
        $keyboard = json_encode([
            "inline_keyboard" => [
                [
                    ["text" => "Atras", "callback_data" => "return"]
                    ],
                    [
                    ["text" => "Siguiente", "callback_data" => "tools1"]
                ]
            ]
        ]);

        /*$content = [
            'chat_id' => $callbackchatid,
            'text' => ,
            'message_id' => $callbackmessageid,
            'reply_markup' => $keyboard,
            'parse_mode' => 'HTML'
        ];
        EditMessageText($content);*/
$content = ['chat_id' => $callbackchatid,'photo'=> 'xtrachkbot.alwaysdata.net/project/th.jpeg','caption' => $herramientas, 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditCaption($content);
    }
}


/* The code that is executed when the user clicks on the "Info" button. */
if ($data == "info") {
    if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
    } else {
        $keyboard = json_encode([
            "inline_keyboard" => [
                [
                    ["text" => "$infboton", "callback_data" => "return"]
                ]
            ]
        ]);

$sql = "select * from administrar where id='$callbackuserid'";
$cs = mysqli_query(mysqlcon(),$sql);
$raw = mysqli_fetch_assoc($cs);
$planexpiry = $raw['planexpiry'];
$credits = $raw['creditos'];
$plan = $raw['plan'];
$title = $raw['rango'];
$antispam = $raw['antispam2'];
$date = $raw['sk'];
$warns = $raw['warns'];
mysqli_close(mysqlcon());
$information = "<b>[☩] Información del Usuario: @$callbackusername
━ ━ ━ ━ ━ ━ ━ ━
↳ ID: $callbackuserid
↳ Estado: $title
↳ Registrado: $date
━ ━ ━ ━
↳ Plan: $plan
↳ Créditos: $credits
↳ Anti-spam: $antispam
━ ━ ━ ━ ━ ━</b>";
$content = ['chat_id' => $callbackchatid,'photo'=> 'xtrachkbot.alwaysdata.net/project/th.jpeg','caption' => $information, 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard, 'parse_mode' => 'HTML'];
        EditCaption($content);
    }
}

/* This is the code that is executed when the user clicks on the "Finalize" button. */
if ($data == "exit") {
    if ($callbackfrom != $callbackuserid) {
        $content = ['callback_query_id' => $callbackid, 'text' => $alert, "show_alert" => true];
        answerCallbackQuery($content);
    } else {
       /* $content = [
            'chat_id' => $callbackchatid,
            'text' => "𝑮𝒐𝒐𝒅𝒃𝒚𝒆! <a href='t.me/$callbackusername'>$callbackfname</a>.",
            'message_id' => $callbackmessageid,
            'reply_markup' => $keyboard,
            'disable_web_page_preview' => true,
            'parse_mode' => 'HTML'
        ];*/
        $content = ['chat_id' => $callbackchatid,'photo'=> 'xtrachkbot.alwaysdata.net/project/th.jpeg','caption' => $cerrare, 'message_id' => $callbackmessageid, 'reply_markup' => $keyboard,'disable_web_page_preview' => true, 'parse_mode' => 'HTML'];
        EditCaption($content);
    }
}