<?php

$not_allowed = "<b>𝗨𝗦𝗘𝗥 𝗡𝗢𝗧 𝗔𝗨𝗧𝗢𝗥𝗜𝗭𝗘𝗗 𝗧𝗢 𝗨𝗦𝗘 𝗠𝗘.🚫\n𝗧𝗢 𝗕𝗘 𝗔𝗕𝗟𝗘 𝗧𝗢 𝗔𝗨𝗧𝗛𝗢𝗥𝗜𝗭𝗘 𝗧𝗛𝗘 𝗙𝗔𝗩𝗢𝗥 𝗢𝗙 𝗖𝗢𝗡𝗧𝗔𝗖𝗧𝗜𝗡𝗚 𝗧𝗛𝗘:  @Ceshack7 𝗔𝗡𝗗 @Gabrielgodzzz</b>";
$not_registered = "<b>═══════════════\nNot Registered\n═══════════════</b>\n[★] Comments : regístrese usando /registrar</b>";
$group_not_allowed = "<b>𝗧𝗛𝗜𝗦 𝗖𝗛𝗔𝗧 𝗡𝗢𝗧 𝗔𝗨𝗧𝗢𝗥𝗜𝗭𝗘𝗗 𝗧𝗢 𝗨𝗦𝗘 𝗠𝗘🚫\n𝗧𝗢 𝗕𝗘 𝗔𝗕𝗟𝗘 𝗧𝗢 𝗔𝗨𝗧𝗛𝗢𝗥𝗜𝗭𝗘 𝗧𝗛𝗘 𝗙𝗔𝗩𝗢𝗥 𝗢𝗙 𝗖𝗢𝗡𝗧𝗔𝗖𝗧𝗜𝗡𝗚 𝗧𝗛𝗘 @Ceshack7  𝗔𝗡𝗗 @Gabrielgodzzz.</b>";
$premium_expired = "<b>═══════════════\nUser Demoted\n═══════════════</b>\n[★] Comments : <b>Compra una membresía premium para usarme de nuevo /prices para más información</b>";
$gate_not_available = "<b>═══════════════\nGateway Not Found\n═══════════════</b>\n[★] Comments : <b>Reportar este problema a mi dueño @Ceshack7</b>";
$used_key = "<b>═══════════════\nAlready Used Key\n═══════════════</b>\n[★] Comments : <b>Esta clave ya fue canjeada</b>";
$invalid_key = "<b>═══════════════\nInvalid Key\n═══════════════</b>\n[★] Comments : <b>Su clave proporcionada no es válida</b>";
$gate_not_allowed = "<b>═══════════════\nUnauthorized User\n═══════════════</b>\n[★] Comments : <b>Purchase premium from owner yo use this gate</b>";
$sk_not_found = "<b>═══════════════\nSECRET_KEY N/A\n═══════════════</b>\n[★] Comments : <b>Add your STRIPE_SECRET using cmd</b>";